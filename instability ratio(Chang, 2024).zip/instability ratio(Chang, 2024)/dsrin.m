	function [Ptrpl,Ttrpl,Btrpl,str2,dip2,rake2]=dsrin(str,dip,rake)
%
%	Calculates other representations of fault planes with
%C		dip, strike and rake (A&R convinention) input.  All
%C		angles are in radians.
%C-
	SR2=0.707107;
    str=deg2rad(str);dip=deg2rad(dip);rake=deg2rad(rake);
	%Transform strike dip and rake to vector of A and N
	A=[cos(rake)*cos(str)+sin(rake)*cos(dip)*sin(str) cos(rake)*sin(str)-sin(rake)*cos(dip)*cos(str) -sin(rake)*sin(dip)];
	N=[-sin(str)*sin(dip) cos(str)*sin(dip) -cos(dip)];
    T=SR2*(A+N);
    P=SR2*(A-N);
    B=cross(P,T);
    [Ptrpl]=v2trpl(P);
	[Ttrpl]=v2trpl(T);
	[Btrpl]=v2trpl(B);
    [str2,dip2,rake2]=an2dsr(N,A);
	return

