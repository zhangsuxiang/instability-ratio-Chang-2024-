function instability_value = compute_instability(R, friction, strike, dip, sigma1_params, sigma2_params, sigma3_params)
% 计算断层在给定主应力条件下的不稳定性
%
% 输入：
%   R              - 主应力比 R=(σ1-σ2)/(σ1-σ3)
%   friction       - 摩擦系数
%   strike         - 断层走向 (度)
%   dip            - 断层倾角 (度)
%   sigma1_params  - σ1主应力轴方位角和倾伏角 [azimuth, plunge]（单位：度）
%   sigma2_params  - σ2主应力轴方位角和倾伏角 [azimuth, plunge]（单位：度）
%   sigma3_params  - σ3主应力轴方位角和倾伏角 [azimuth, plunge]（单位：度）
%
% 输出：
%   instability_value - 断层的不稳定性大小值

% 计算断层面法向量 (n1, n2, n3)
[n1, n2, n3] = fault_normal_vector(strike, dip);

% 计算主应力轴的方向向量
[sigma1_vec] = stress_axis_vector(sigma1_params);
[sigma2_vec] = stress_axis_vector(sigma2_params);
[sigma3_vec] = stress_axis_vector(sigma3_params);

% 计算法向与三个主应力轴的夹角
theta1 = angle_between_vectors([n1, n2, n3], sigma1_vec);
theta2 = angle_between_vectors([n1, n2, n3], sigma2_vec);
theta3 = angle_between_vectors([n1, n2, n3], sigma3_vec);

% 计算法向应力、剪切应力及不稳定性
ns = n1.^2 + (1-2*R)*n2.^2 - n3.^2;
ss = sqrt( ( n1.^2 + (1-2*R)^2*n2.^2 + n3.^2 ) - ns.^2 );
instability_value = ( ss - friction*(ns-1) ) / ( friction + sqrt(1+friction^2) );

end


function [n1, n2, n3] = fault_normal_vector(strike, dip)
% 计算断层法向向量 (n1, n2, n3)
%
% strike - 走向（角度制，0°为北，顺时针）
% dip - 倾角（角度制，0°水平，90°垂直）

strike_rad = deg2rad(strike);  % 走向角转换为弧度
dip_rad = deg2rad(dip);        % 倾角转换为弧度

% 计算断层法向量
n1 = sin(dip_rad) * cos(strike_rad);
n2 = sin(dip_rad) * sin(strike_rad);
n3 = cos(dip_rad);

end


function [vector] = stress_axis_vector(stress_params)
% 计算主应力轴的方向向量
% stress_params = [azimuth, plunge]（单位：度）

azimuth = deg2rad(stress_params(1));  % 方位角
plunge = deg2rad(stress_params(2));   % 倾伏角

% 计算主应力轴的方向向量
x = cos(plunge) * sin(azimuth);
y = cos(plunge) * cos(azimuth);
z = sin(plunge);

vector = [x, y, z];

end


function theta = angle_between_vectors(vec1, vec2)
% 计算两个向量之间的夹角
% 输入：vec1 和 vec2 为 3D 向量
theta = acos(dot(vec1, vec2) / (norm(vec1) * norm(vec2)));
end