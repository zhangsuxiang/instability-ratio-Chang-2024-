function[str1,dip1,rake1,str2,dip2,rake2,Btrpl,PTangle]=pt2ds(Ptrpl,Ttrpl)
%采用震源机制的PT轴的走向和倾伏角求解震源机制的其他表示形式
%输入：Ptrpl为P轴的走向和倾伏角，Ttrpl为T轴的走向和倾伏角，单位均为度
%输出：str1,dip1,rake1为第一个节面走向，倾角和滑动角
%Btrpl为B轴的走向和倾伏角
%PTangle为P轴，T轴之间的夹角，接近90°
SR2=0.707107;
Ptrpl = deg2rad(Ptrpl);Ttrpl = deg2rad(Ttrpl);
P = [cos(Ptrpl(1))*cos(Ptrpl(2)) sin(Ptrpl(1))*cos(Ptrpl(2)) sin(Ptrpl(2))];
T = [cos(Ttrpl(1))*cos(Ttrpl(2)) sin(Ttrpl(1))*cos(Ttrpl(2)) sin(Ttrpl(2))];
PTangle = rad2deg(acos(dot(P,T)));
if(abs(PTangle-90)>10)
    warning('两个节面不垂直')
end
B=cross(T,P);
A = SR2*(T+P);
N = SR2*(T-P);
Btrpl=v2trpl(B);
[str1,dip1,rake1]=an2dsr(A,N);
[str2,dip2,rake2]=an2dsr(N,A);