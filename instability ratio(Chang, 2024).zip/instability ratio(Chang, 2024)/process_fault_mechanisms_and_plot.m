function selected_planes = process_fault_mechanisms_and_plot(data, R, friction, sigma1_params, sigma2_params, sigma3_params, IR_threshold)
% 处理一组震源机制解数据，计算节面Ⅱ，筛选 IR > 阈值的节面，并绘制 IR vs. 不稳定性系数的平面图
%
% 输入：
%   data            - N×3 矩阵，每行 [strike1, dip1, rake1]（单位：度）
%   R               - 主应力比 R=(σ1-σ2)/(σ1-σ3)
%   friction        - 摩擦系数
%   sigma1_params   - σ1 轴的方位角和倾伏角 [azimuth, plunge]（单位：度）
%   sigma2_params   - σ2 轴的方位角和倾伏角 [azimuth, plunge]（单位：度）
%   sigma3_params   - σ3 轴的方位角和倾伏角 [azimuth, plunge]（单位：度）
%   IR_threshold    - 筛选阈值，若 IR > 阈值，则记录对应节面
%
% 输出：
%   selected_planes - M×3 矩阵（M ≤ N），存储满足 IR > 阈值的节面：[strike, dip, rake]

selected_planes = []; % 用于存储符合条件的节面
IR_values = []; % 存储每个震源机制的 IR 值
max_instability_values = []; % 存储不稳定性最大值
below_threshold = []; % 存储低于 IR 阈值的点
above_threshold = []; % 存储高于 IR 阈值的点
min_instability_above = []; % 存储 IR > 阈值数据中最优节面的不稳定性

for i = 1:size(data, 1)
    % 获取当前震源机制解 (节面 I)
    strike1 = data(i, 1);
    dip1 = data(i, 2);
    rake1 = data(i, 3);
    
    % 计算节面 II
    [~, ~, ~, strike2, dip2, rake2] = dsrin(strike1, dip1, rake1);
    
    % 计算节面 I 和节面 II 的不稳定性系数
    instability1 = compute_instability(R, friction, strike1, dip1, sigma1_params, sigma2_params, sigma3_params);
    instability2 = compute_instability(R, friction, strike2, dip2, sigma1_params, sigma2_params, sigma3_params);
    
    % 计算 IR 值
    max_instability = max(instability1, instability2);
    min_instability = min(instability1, instability2);
    IR = max_instability / min_instability;
    
    % 记录所有震源机制的 IR 和最大不稳定性
    IR_values = [IR_values; IR];
    max_instability_values = [max_instability_values; max_instability];

    % 根据 IR 阈值分类数据点
    if IR > IR_threshold
        above_threshold = [above_threshold; IR, max_instability];
        min_instability_above = [min_instability_above; max_instability]; % 记录 IR > 阈值点的最优节面最大不稳定性
        if instability1 > instability2
            selected_planes = [selected_planes; strike1, dip1, rake1]; % 记录节面 I
        else
            selected_planes = [selected_planes; strike2, dip2, rake2]; % 记录节面 II
        end
    else
        below_threshold = [below_threshold; IR, max_instability];
    end
end

% 绘制 IR vs. 最大不稳定性
figure;
hold on;

% 绘制小于 IR 阈值的点（红色 x）
if ~isempty(below_threshold)
    scatter(below_threshold(:,1), below_threshold(:,2), 60, 'r', 'x', 'LineWidth', 1.5);
end

% 绘制大于 IR 阈值的点（蓝色 o）
if ~isempty(above_threshold)
    scatter(above_threshold(:,1), above_threshold(:,2), 60, 'b', 'o', 'LineWidth', 1.5);
end

% 绘制 IR 阈值红色直线并标注 'Threshold IR'
xline(IR_threshold, 'r', 'LineWidth', 2);
text(IR_threshold, 0.9, 'Threshold IR', 'FontSize', 12, 'Color', 'r', 'FontWeight', 'bold', 'Rotation', 90, 'HorizontalAlignment', 'right');

% 计算并绘制 'Baseline I'
if ~isempty(min_instability_above)
    baseline_I = min(min_instability_above); % 计算 IR > 阈值数据中最优节面的最小不稳定性
    yline(baseline_I, '--k', 'LineWidth', 1.5);
    text(2.9, baseline_I + 0.02, 'Baseline I', 'FontSize', 12, 'Color', 'k', 'FontWeight', 'bold', 'HorizontalAlignment', 'right');
end
% 设置 X 和 Y 轴范围
xlim([1, 3]);
ylim([0, 1]);

xlabel('Instability ratio (IR)', 'FontSize', 12);
ylabel('Instability (I)', 'FontSize', 12);
hold off;

end