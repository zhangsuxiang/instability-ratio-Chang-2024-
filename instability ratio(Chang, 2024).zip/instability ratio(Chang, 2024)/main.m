clear all;close all;clc;
% 震源机制解数据 (每行：strike, dip, rake)
data = [30, 45, 90;  
        60, 50, 120;
        90, 60, 30;
        40, 70, 110;
        20, 80, 45];

R = 0.5;                % 形状比率
friction = 0.6;         % 摩擦系数
sigma1_params = [60, 30]; % σ1 轴方位角和倾伏角 (单位：度)
sigma2_params = [120, 20]; % σ2 轴方位角和倾伏角 (单位：度)
sigma3_params = [240, 10]; % σ3 轴方位角和倾伏角 (单位：度)
IR_threshold = 1.2;     % 设定 IR 阈值

selected_planes = process_fault_mechanisms_and_plot(data, R, friction, sigma1_params, sigma2_params, sigma3_params, IR_threshold);

disp('满足 IR > 阈值 的节面:');
disp(selected_planes);